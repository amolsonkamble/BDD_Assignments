import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Cal_demo {
    WebDriver driver;
    @BeforeTest
    public void initiallitize()
    {

        // System.setProperty("webDriver.chrome.driver", "C:/Users/amol.sonkamble.saama/Downloads/chromedriver.exe");
        WebDriverManager.chromedriver().setup();
         driver = new ChromeDriver();
        driver.get("https://www.calculator.net/bmi-calculator.html?ctype=metric");
        driver.manage().window().maximize();
    }

    @Test
    void calculate () throws InterruptedException {
        WebElement ageElement= driver.findElement(By.xpath("//*[@id=\"cage\"]"));

        ageElement.clear();
        ageElement.sendKeys("20");
        Thread.sleep(1000);

        WebElement genderElement=driver.findElement(By.xpath("//tbody/tr[2]/td[2]/label[1]"));
        //genderElement.clear();
        genderElement.click();

        WebElement heightElement=driver.findElement(By.xpath("//*[@id=\"cheightmeter\"]"));
        heightElement.clear();
        heightElement.sendKeys("180");
        Thread.sleep(1000);

        WebElement weightElement= driver.findElement(By.xpath("//*[@id=\"ckg\"]"));
        weightElement.clear();
        weightElement.sendKeys("60");
        Thread.sleep(1000);
        WebElement result= driver.findElement(By.cssSelector("#content > div.leftinput > div.panel2 > table > tbody > tr > td > table:nth-child(4) > tbody > tr > td > input[type=image]:nth-child(2)"));
        result.click();
        Thread.sleep(1000);
        WebElement actual_result= driver.findElement(By.tagName("b"));
        String res=actual_result.getText();

        Assert.assertEquals("BMI = 18.5 kg/m2",res);

    }

    @Test
    void calculate1 () throws InterruptedException {
        WebElement ageElement= driver.findElement(By.xpath("//*[@id=\"cage\"]"));

        ageElement.clear();
        ageElement.sendKeys("35");
        Thread.sleep(1000);

        WebElement genderElement=driver.findElement(By.xpath("//*[@id=\"calinputtable\"]/tbody/tr[2]/td[2]/label[2]/span"));
        //genderElement.clear();
        genderElement.click();

        WebElement heightElement=driver.findElement(By.xpath("//*[@id=\"cheightmeter\"]"));
        heightElement.clear();
        heightElement.sendKeys("160");
        Thread.sleep(1000);

        WebElement weightElement= driver.findElement(By.xpath("//*[@id=\"ckg\"]"));
        weightElement.clear();
        weightElement.sendKeys("55");
        Thread.sleep(1000);
        WebElement result= driver.findElement(By.cssSelector("#content > div.leftinput > div.panel2 > table > tbody > tr > td > table:nth-child(4) > tbody > tr > td > input[type=image]:nth-child(2)"));
        result.click();
        Thread.sleep(1000);
        WebElement actual_result= driver.findElement(By.tagName("b"));
        String res=actual_result.getText();

        Assert.assertEquals("BMI = 21.5 kg/m2",res);

    }

    @Test
    void calculate2 () throws InterruptedException {
        WebElement ageElement= driver.findElement(By.xpath("//*[@id=\"cage\"]"));

        ageElement.clear();
        ageElement.sendKeys("50");
        Thread.sleep(1000);

        WebElement genderElement=driver.findElement(By.xpath("//tbody/tr[2]/td[2]/label[1]"));
        //genderElement.clear();
        genderElement.click();

        WebElement heightElement=driver.findElement(By.xpath("//*[@id=\"cheightmeter\"]"));
        heightElement.clear();
        heightElement.sendKeys("175");
        Thread.sleep(1000);

        WebElement weightElement= driver.findElement(By.xpath("//*[@id=\"ckg\"]"));
        weightElement.clear();
        weightElement.sendKeys("65");
        Thread.sleep(1000);
        WebElement result= driver.findElement(By.cssSelector("#content > div.leftinput > div.panel2 > table > tbody > tr > td > table:nth-child(4) > tbody > tr > td > input[type=image]:nth-child(2)"));
        result.click();
        Thread.sleep(1000);
        WebElement actual_result= driver.findElement(By.tagName("b"));
        String res=actual_result.getText();

        Assert.assertEquals("BMI = 21.2 kg/m2",res);

    }

    @Test
    void calculate3 () throws InterruptedException {
        WebElement ageElement= driver.findElement(By.xpath("//*[@id=\"cage\"]"));

        ageElement.clear();
        ageElement.sendKeys("45");
        Thread.sleep(1000);

        WebElement genderElement=driver.findElement(By.xpath("//*[@id=\"calinputtable\"]/tbody/tr[2]/td[2]/label[2]/span"));
        //genderElement.clear();
        genderElement.click();

        WebElement heightElement=driver.findElement(By.xpath("//*[@id=\"cheightmeter\"]"));
        heightElement.clear();
        heightElement.sendKeys("150");
        Thread.sleep(1000);

        WebElement weightElement= driver.findElement(By.xpath("//*[@id=\"ckg\"]"));
        weightElement.clear();
        weightElement.sendKeys("52");
        Thread.sleep(1000);
        WebElement result= driver.findElement(By.cssSelector("#content > div.leftinput > div.panel2 > table > tbody > tr > td > table:nth-child(4) > tbody > tr > td > input[type=image]:nth-child(2)"));
        result.click();
        Thread.sleep(1000);
        WebElement actual_result= driver.findElement(By.tagName("b"));
        String res=actual_result.getText();

        Assert.assertEquals("BMI = 23.1 kg/m2",res);

    }
    @AfterTest
    void close_driver()
    {
        driver.quit();
    }
}
