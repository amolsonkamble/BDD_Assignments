package Step;

import Page.BMI_page;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BMI_step {
    WebDriver driver;
    BMI_page bmi_page;

    @Given("I am on BMI Calculator page")
    public void iAmOnBMICalculatorPage() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        bmi_page= new BMI_page(driver);
    }

    @When("I enter <age> in calculator")
    public void iEnterAgeInCalculator() {
        bmi_page.age();
    }

    @And("I Press <gender> in calculator")
    public void iPressGenderInCalculator() {
        bmi_page.gender();
    }

    @And("I Press <calculate>in calculator")
    public void iPressCalculateInCalculator() {
    }

    @Then("I see the result is <result>")
    public void iSeeTheResultIsResult() {
        bmi_page.result();
    }

    @And("I enter <height and weight> in calculator")
    public void iEnterHeightAndWeightInCalculator() {
        bmi_page.height();
        bmi_page.weight();
    }
}
