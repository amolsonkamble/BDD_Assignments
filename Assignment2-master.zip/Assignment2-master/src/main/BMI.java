import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class BMI {
    WebDriver driver;

    @BeforeMethod
    void initialize(){
        //System.setProperty("webdriver.chrome.driver","src/test/Resourses/chromedriver.exe");
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get(" https://www.calculator.net/bmi-calculator.html?ctype=metric");
        driver.manage().window().maximize();
    }

   /* @Test
    void testBMI() throws InterruptedException {
        WebElement age= driver.findElement(By.xpath("//*[@id=\"cage\"]"));//age
        age.clear();
        age.sendKeys("20");
        Thread.sleep(1000);

        WebElement radio=driver.findElement(By.xpath("//*[@id=\"calinputtable\"]/tbody/tr[2]/td[2]/label[1]")); //gender
        radio.click();

        WebElement height=driver.findElement(By.xpath("//*[@id=\"cheightmeter\"]")); //height
        height.clear();
        height.sendKeys("180");
        Thread.sleep(1000);

        WebElement w=driver.findElement(By.xpath("//*[@id=\"ckg\"]")); //weight
        w.clear();
        w.sendKeys("60");
        Thread.sleep(1000);

        WebElement cal_button=driver.findElement(By.cssSelector("#content > div.leftinput > div.panel2 > table > tbody > tr > td > table:nth-child(4) > tbody > tr > td > input[type=image]:nth-child(2)"));// calculate button
        cal_button.click();
        Thread.sleep(1000);

        WebElement actual=driver.findElement(By.cssSelector("#content > div.rightresult > div > b"));
        String result=actual.getText();
       Assert.assertEquals("BMI = 18.5 kg/m2",result);
    }
    @Test
    void test2() throws InterruptedException {
        WebElement age= driver.findElement(By.xpath("//*[@id=\"cage\"]"));//age
        age.clear();
        age.sendKeys("35");
        Thread.sleep(1000);
        WebElement radio=driver.findElement(By.xpath("//*[@id=\"calinputtable\"]/tbody/tr[2]/td[2]/label[2]/span")); //gender

        radio.click();
        WebElement height=driver.findElement(By.xpath("//*[@id=\"cheightmeter\"]")); //height
        height.clear();
        height.sendKeys("160");
        Thread.sleep(1000);

        WebElement w=driver.findElement(By.xpath("//*[@id=\"ckg\"]")); //weight
        w.clear();
        w.sendKeys("55");
        Thread.sleep(1000);

        WebElement cal_button=driver.findElement(By.cssSelector("#content > div.leftinput > div.panel2 > table > tbody > tr > td > table:nth-child(4) > tbody > tr > td > input[type=image]:nth-child(2)"));// calculate button
        cal_button.click();
        Thread.sleep(1000);

        WebElement actual=driver.findElement(By.cssSelector("#content > div.rightresult > div > b"));
        String result=actual.getText();
        Assert.assertEquals("BMI = 21.5 kg/m2",result);
    }
    @Test
    void test3() throws InterruptedException {
        WebElement age= driver.findElement(By.xpath("//*[@id=\"cage\"]"));//age
        age.clear();
        age.sendKeys("50");
        Thread.sleep(1000);
        WebElement radio=driver.findElement(By.xpath("//*[@id=\"calinputtable\"]/tbody/tr[2]/td[2]/label[1]")); //gender

        radio.click();
        WebElement height=driver.findElement(By.xpath("//*[@id=\"cheightmeter\"]")); //height
        height.clear();
        height.sendKeys("175");
        Thread.sleep(1000);

        WebElement w=driver.findElement(By.xpath("//*[@id=\"ckg\"]")); //weight
        w.clear();
        w.sendKeys("65");
        Thread.sleep(1000);

        WebElement cal_button=driver.findElement(By.cssSelector("#content > div.leftinput > div.panel2 > table > tbody > tr > td > table:nth-child(4) > tbody > tr > td > input[type=image]:nth-child(2)"));// calculate button
        cal_button.click();
        Thread.sleep(1000);

        WebElement actual=driver.findElement(By.cssSelector("#content > div.rightresult > div > b"));
        String result=actual.getText();
        Assert.assertEquals("BMI = 21.2 kg/m2",result);
    }
    @Test
    void test4() throws InterruptedException {
        WebElement age= driver.findElement(By.xpath("//*[@id=\"cage\"]"));//age
        age.clear();
        age.sendKeys("45");
        Thread.sleep(1000);
        WebElement radio=driver.findElement(By.xpath("//*[@id=\"calinputtable\"]/tbody/tr[2]/td[2]/label[2]/span")); //gender

        radio.click();
        WebElement height=driver.findElement(By.xpath("//*[@id=\"cheightmeter\"]")); //height
        height.clear();
        height.sendKeys("150");
        Thread.sleep(1000);

        WebElement w=driver.findElement(By.xpath("//*[@id=\"ckg\"]")); //weight
        w.clear();
        w.sendKeys("52");
        Thread.sleep(1000);

        WebElement cal_button=driver.findElement(By.cssSelector("#content > div.leftinput > div.panel2 > table > tbody > tr > td > table:nth-child(4) > tbody > tr > td > input[type=image]:nth-child(2)"));// calculate button
        cal_button.click();
        Thread.sleep(1000);

        WebElement actual=driver.findElement(By.cssSelector("#content > div.rightresult > div > b"));
        String result=actual.getText();
        Assert.assertEquals("BMI = 23.1 kg/m2",result);
    }
    @AfterTest
    void Close_Driver(){
        driver.quit();
    }*/
}
