package Page;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class BMI_Page {
    WebDriver driver;
    public BMI_Page(WebDriver driver1){
        driver=driver1;
        driver.get("https://www.calculator.net/bmi-calculator.html?ctype=metric");
        driver.manage().window().maximize();
    }
   public  void AgeCalculate()throws InterruptedException{
        WebElement age= driver.findElement(By.xpath("//*[@id=\"cage\"]"));//age
        age.clear();
        age.sendKeys("20");
        Thread.sleep(1000);
    }
   public void VerifyGender(){
        WebElement radio=driver.findElement(By.xpath("//*[@id=\"calinputtable\"]/tbody/tr[2]/td[2]/label[1]")); //gender
        radio.click();
    }
    public void VerifyHeight()throws InterruptedException{
        WebElement height=driver.findElement(By.xpath("//*[@id=\"cheightmeter\"]")); //height
        height.clear();
        height.sendKeys("180");
        Thread.sleep(1000);
    }
    public void VerifyWeight()throws InterruptedException{
        WebElement weight=driver.findElement(By.xpath("//*[@id=\"ckg\"]")); //weight
        weight.clear();
        weight.sendKeys("60");
        Thread.sleep(1000);
    }
    public void VerifyButton() throws InterruptedException{
        WebElement cal_button=driver.findElement(By.cssSelector("#content > div.leftinput > div.panel2 > table > tbody > tr > td > table:nth-child(4) > tbody > tr > td > input[type=image]:nth-child(2)"));// calculate button
        cal_button.click();
        Thread.sleep(1000);
    }
   public void Result(){
        WebElement actual_result=driver.findElement(By.cssSelector("#content > div.rightresult > div > b"));
        String result=actual_result.getText();
        Assert.assertEquals("BMI = 18.5 kg/m2",result);
    }
}
