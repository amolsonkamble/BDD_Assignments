package Step;

import Page.BMI_Page;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BMI_Steps {
    WebDriver driver;
    BMI_Page bmi_page;
    @Given("I am on BMI Calculator Page")
    public void iAmOnBMICalculatorPage() {

        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        bmi_page=new BMI_Page(driver);
        driver.get(" https://www.calculator.net/bmi-calculator.html?ctype=metric");
        driver.manage().window().maximize();
    }

    @When("I enter <age>in calculator")
    public void iEnterAgeInCalculator() throws InterruptedException {
        bmi_page.AgeCalculate();
    }

    @And("I select <Gender> in calculator")
    public void iSelectGenderInCalculator() {
        bmi_page.VerifyGender();
    }
    @And("I enter <Height and Weight>in calculator")
    public void iEnterHeightAndWeightInCalculator() throws InterruptedException {
        bmi_page.VerifyHeight();
        bmi_page.VerifyWeight();
    }

    @And("I press <calculate>in calculator")
    public void iPressCalculateInCalculator() throws InterruptedException {
        bmi_page.VerifyButton();
    }

    @Then("I see the <result>")
    public void iSeeTheResult() {
        bmi_page.Result();
    }


}
