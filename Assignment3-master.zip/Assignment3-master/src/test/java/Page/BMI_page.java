package Page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class BMI_page {

    WebDriver driver;
    public BMI_page(WebDriver driver1)
    {
        driver= driver1;
        driver.get("https://www.calculator.net/bmi-calculator.html ");//put BMI calculator url
        driver.manage().window().maximize();
    }

    public void age()  {
        WebElement ageElement= driver.findElement(By.xpath("//*[@id=\"cage\"]"));

        ageElement.clear();
        ageElement.sendKeys("20");

    }
    public void gender() {

        WebElement genderElement=driver.findElement(By.xpath("//tbody/tr[2]/td[2]/label[1]"));
        //genderElement.clear();
        genderElement.click();

    }
    public void height() {
        WebElement heightElement=driver.findElement(By.xpath("//*[@id=\"cheightmeter\"]"));
        heightElement.clear();
        heightElement.sendKeys("180");

    }
    public void weight()  {
        WebElement weightElement= driver.findElement(By.xpath("//*[@id=\"ckg\"]"));
        weightElement.clear();
        weightElement.sendKeys("60");

    }
    public void result()  {
        WebElement result= driver.findElement(By.cssSelector("#content > div.leftinput > div.panel2 > table > tbody > tr > td > table:nth-child(4) > tbody > tr > td > input[type=image]:nth-child(2)"));
        result.click();

        WebElement actual_result= driver.findElement(By.tagName("b"));
        String res=actual_result.getText();
        Assert.assertEquals("BMI = 18.5 kg/m2",res);
    }


}

