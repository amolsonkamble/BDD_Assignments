package Utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestContext {

    public static WebDriver driver;
    public static WebDriverWait wait;

}

